Setup xqueue, port 1710, for example: "java-queue": "http://localhost:1710"

Copy /edx/java-grader

Import edX course: 2014_T12.R1tVlz.tar.gz

Run: sudo python JavaGrader.py
